package ecommercesystem;


import ecommercesystem.Product;


public class Cart {
    private int customerId;
    private int nProducts;
    private Product[] products;

    public Cart() {
    }

    
     public Cart(int customerId, int nProducts) {
        this.customerId = Math.abs(customerId); 
        this.nProducts = Math.abs(nProducts); 
        this.products = new Product[nProducts]; 
    }
     
    public void setCustomerId(int customerId) {
        this.customerId = Math.abs(customerId);
    }

    public void setnProducts(int nProducts) {
        this.nProducts = Math.abs(nProducts);
    }

    public void setProducts(Product[] products) {
        this.products = products;
    }

    public int getCustomerId() {
        return customerId;
    }

    public int getnProducts() {
        return nProducts;
    }

    public Product[] getProducts() {
        return products;
    }
    public void addProduct(Product product){
        for(int i=0;i<nProducts;i++){
            if(products[i]==null){
                products[i]=product;
                break;
            }
        }
    }   
    public void removeProduct(Product product) {
        boolean x = false;
         for (int i = 0; i < nProducts; i++) {
             if (products[i]==product) {
                 for (int j = i; j < nProducts - 1; j++) {
                products[j] = products[j + 1];
             }
                 nProducts--;
                 x=true;
                 System.out.println("The product is removed from the cart");
                 break;
         }
    }
 if(!x) {
        System.out.println("Product not found in the cart.");
}    
    }
    public float calculatePrice() {
        float totalPrice = 0;
        for (int i = 0; i < nProducts; i++) {
            totalPrice += products[i].getPrice();
        }
        return totalPrice;
    }
    public void placeOrder(Order o1){
        if (nProducts == 0) {
        System.out.println("Cannot place order. Cart is empty.");
        return;
    }
         
        o1.printOrderInfo();
        clearCart();
          
        }
    private void clearCart(){
         nProducts = 0;
         products = new Product[products.length];
        }
    }
    
