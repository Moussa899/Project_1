
package ecommercesystem;

import java.util.Scanner;
public class EcommerceSystem {
    
    public static void main(String[] args) {
       Scanner s = new Scanner(System.in);
        System.out.println("Welcome to the E-commerce system!");
        System.out.println("Please enter your ID: ");
        Customer c1 = new Customer();
        int Id = s.nextInt();
        c1.setCustomerId(Id);
        s.nextLine();
        System.out.println("Please enter your name :");
        String name = s.nextLine();
        c1.setName(name);
        System.out.println("Please enter your adress: ");
        String a = s.next();
        c1.setAddress(a);
        System.out.println("How many products would you like to add to your cart?");
        int numProduct = s.nextInt();
        Cart cart = new Cart(c1.getCustomerId(),numProduct);
        for(int i=0;i<numProduct;i++){
            System.out.println("Which product would you like to add? 1- Smartphone 2- T-shirt 3- OOP book");
            int x =s.nextInt();
            switch(x){
                case 1 -> cart.addProduct(new ElectronicProduct(1,"Smartphone",599.99f,"Samsung",1));
                case 2 -> cart.addProduct(new ClothingProduct(2,"T-shirt",19.99f,"Large","Cotton"));
                case 3 -> cart.addProduct(new BookProduct(3,"OOP book",39.99f,"O’Reilly","X Publications"));
                default -> {
                    System.out.println("Invalid input,please try again");
                    i--;
               }
            }
        }
        System.out.println("Here's your order's summary: ");
        Order o1 = new Order(c1.getCustomerId(),1,cart.getProducts(),cart.calculatePrice());
        o1.printOrderInfo();
        System.out.println("Do you want to place the order? (yes/no)");
        String y = s.next().toLowerCase();
        if ("yes".equals(y)){
            cart.placeOrder(o1);
            System.out.println("Thank you for using E-commerce System");
        }else{
            System.out.println("Order cancelled.");
            System.out.println("Thank you for using E-commerce System");
        }
    }
    
}
